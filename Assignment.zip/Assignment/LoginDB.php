<!-- //This page displays the logged-in user's data from database in html table format -->
<!DOCTYPE html>
<html>
<head>
        <title>User Profile</title>
        <link rel="stylesheet" type="text/css" href="stylesheet.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <?php require("heading.php"); ?>
</head>
<body style="background-color:darkseagreen;">   

<?php
include('UserCheck.php');
if (isset($_SESSION['username']))
{
    require 'dbconnect.php';
    
    $email=$_SESSION['username'];//getting email-id stored in session
  
        
    echo "<table border='5'>
    <tr>
<th>Firstname</th>
<th>Lastname</th>
<th>Gender</th>
<th>Email</th>
<th>Address</th>
<th>Street</th>
<th>Suburb</th>
<th>City</th>
<th>P.O</th>
<th>Mobile</th>
<th>Date Of Birth</th>
</tr>";
  //Retrieving data from database for the logged in user.
  $sql="SELECT * FROM UserDetails WHERE Email LIKE '$email'";
  $result=mysqli_query($mysqli,$sql);
    while($row = mysqli_fetch_array($result))
    {
        echo '</br>';
        echo "Hello ".$row['FirstName'].",";
        echo "<tr>";
        echo "<td>" . $row['FirstName'] . "</td>";
        echo "<td>" . $row['LastName'] . "</td>";
        echo "<td>" . $row['Gender'] . "</td>";
        echo "<td>" . $row['Email'] . "</td>";
        echo "<td>" . $row['Address'] . "</td>";
        echo "<td>" . $row['Street'] . "</td>";
        echo "<td>" . $row['Suburb'] . "</td>";
        echo "<td>" . $row['City'] . "</td>";
        echo "<td>" . $row['PO'] . "</td>";
        echo "<td>" . $row['Mobile'] . "</td>";
        echo "<td>" . $row['DOB'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
        echo '</br>';   
        echo '</br>';   
        echo '</br>';   
 }
 ?>
   <!-- Calling Logout.php to clear session and logout -->
 <a href="Logout.php">Logout</a>
    
    </body>  
    <?php require("footer.php"); ?>
 </html>   

       