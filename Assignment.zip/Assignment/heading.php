 <!--Header for the application -->
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="stylesheet.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
    </head>
    <body> 
            <nav id="navbar">
                <ul style="text-align:right;">
                     <a href="Login.php">Home</a>|
                     <a href="#">About</a>|
                     <a href="#">Contact Us</a>
                </ul>
            </nav>
    </body>
</html>