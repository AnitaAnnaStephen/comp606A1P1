<html>
<head>
        <title>Welcome User</title>
        <link rel="stylesheet" type="text/css" href="stylesheet.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <?php require("heading.php"); ?>
</head>
<body style="background-color:darkseagreen;">   

<?php
include('RegisterDB.php');
if (isset($_SESSION['firstname']))
{
    //require 'dbconnect.php';
    $firstname=$_SESSION['firstname'];
    //Welcome message for the newly registered user.
     echo '<h2>REGISTERATION SUCCESSFUL.!!</h2>';
     echo '<p1>Hello '.$firstname.',</p1>';
     echo '<p>Thank you for registering with us :).We are sure you will find our website useful.</p>';
     echo  '<a href="LoginDB.php">Click here to continue using the website.</a>';
     echo  '</br>';
     echo '<h3> Welcome Aboard!</h3>';                        
}
?>
</body>
<?php require("footer.php"); ?>
</html>