<!-- Page to be displayed if database connection not established -->
<html>
<body>

<h1>Site Down</h1>
<p>We apologize for any inconvenience and are working hard to fix things!</p>

</body>
</html>
