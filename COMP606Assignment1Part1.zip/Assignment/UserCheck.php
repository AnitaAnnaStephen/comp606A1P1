<!-- Page to check if username and password is correct -->
<?php
session_start();
$error="";
if (isset($_POST['login']))
{
    require 'dbconnect.php';//Establishing database connection
    
    $email=$_POST['username'];
    $password=$_POST['password'];
    $password = md5($_REQUEST['password']);//To match password with encrypted password
    //Checking if email id and password matches with database values.
    $sql="SELECT * FROM UserDetails WHERE Email LIKE '$email' AND Password LIKE '$password'";
    $result=mysqli_query($mysqli,$sql);
     if($row = $result->fetch_row())//if username and password is valid
     {
         $_SESSION['username']=$email;//initialising session
         header("Location: LoginDB.php");//redirecting to user profile
    }
    else{//if username or password is invalid
        $error="Invalid username or password";
    }
}
?>