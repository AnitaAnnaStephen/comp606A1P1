
<?php
session_start();
$message='';
if (isset($_POST['register']))
{
    require 'dbconnect.php';
    $gender=$address=$street=$suburb=$city=$po=$dob=$lastname=$firstname=$email=$mobile=$password=$repassword='';
    //Retreiving values sent by http post method
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $gender=$_POST['gender'];
    $email=$_POST['email'];
    $address=$_POST['address'];
    $street=$_POST['street'];
    $suburb=$_POST['suburb'];
    $city=$_POST['city'];
    $po=$_POST['po'];
    $mobile=$_POST['mobile'];
    $dob=$_POST['dob'];
    $password=$_POST['password'];
    $repassword=$_POST['confirmpassword'];
    $today=date('Y/m/d');
    if($password !== $repassword)
    {
        //Checking if passwords match
        $message="Passwords not matching";
        //echo "<script type='text/javascript'>alert('$errormessage');</script>";
    }
    else if($dob>$today)
    {
        $message='Date of birth cannot be a future date';
    }
    else
    {
        //Checking if the email already exists in the database
        $sql="SELECT * FROM UserDetails WHERE Email LIKE '$email'";
        $result=mysqli_query($mysqli,$sql);
        if($row = $result->fetch_row())
        {
           $message="Email already exists in database.";
           //echo "<script type='text/javascript'>alert('Email already exists in database.');</script>";
            //header("Location: Register.php");
            //echo ("Email already exists in database.");
            //exit();
       }
          else
          {
            $password=md5($password);//Password encryption
            //Saving data to the database using SP
            $sqlsp = "CALL spAddUser('$firstname', '$lastname','$gender', '$email', '$address','$street' ,'$suburb' ,'$city',$po,$mobile ,'$dob','$password')";
            if (!$mysqli->query($sqlsp)){
            $message='Failed to register user';
            echo($mysqli->error);
             } 
            else {
                //Saving values to session variables to use later.
                $_SESSION['firstname']=$firstname;
                $_SESSION['username']=$email;
                header("Location: Welcome.php");//redirecting to user profile                       
                }

          }
          
    }
    
     
}
?>
</body>

</html>