<?php
session_start();
$error="";
if (isset($_POST['login']))
{
    require 'dbconnect.php';
    
    $address=$_POST['username'];
    $password=$_POST['password'];
    $password = md5($_REQUEST['password']);//matching password with encrypted password
    //Checking if email id and password matches with database values.
    $sql="SELECT * FROM UserDetails WHERE Email LIKE '$address' AND Password LIKE '$password'";
    $result=mysqli_query($mysqli,$sql);
     if($row = $result->fetch_row())//if username and password is valid
     {
         $_SESSION['username']=$address;//initialising session
         header("Location: LoginDB.php");//redirecting to user profile
    }
    else{//if username or password is invalid
        $error="Invalid username or password";
    }
}
?>